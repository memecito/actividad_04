const listadoLibros = [
  {
    titulo: "Todas esas cosas que te diré mañana",
    genero: "Ficción",
    autor: "Elísabet Benavent",
    isbn: "978-84-9129-597-6",
    peso: 642,
  },
  {
    titulo: "El peligro de estar cuerda",
    genero: "Ensayos literarios",
    autor: "Rosa Montero",
    isbn: "978-84-322-4064-5",
    peso: 484,
  },
  {
    titulo: "Compas 7. Los Compas vs. hackers",
    genero: "Ficción",
    autor: "Mikecrack, El Trollino y Timba Vk",
    isbn: "978-84-270-5000-6",
    peso: 734,
  },
];
